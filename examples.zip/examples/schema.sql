create table company (
  name string,
  count integer
);

create table attribute (
  name string,
  count integer
);

create table sector (
  name string,
  count integer
);
